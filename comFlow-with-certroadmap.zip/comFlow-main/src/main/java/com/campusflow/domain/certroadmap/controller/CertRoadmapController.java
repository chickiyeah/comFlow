package com.campusflow.domain.certroadmap.controller;

import com.campusflow.domain.certroadmap.dto.CertRoadmapDto;
import com.campusflow.domain.certroadmap.service.CertRoadmapService;
import com.campusflow.global.response.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cert-roadmap")
@RequiredArgsConstructor
public class CertRoadmapController {

    private final CertRoadmapService service;

    /** 로드맵 생성 (AI) */
    @PostMapping("/generate")
    public ApiResponse<CertRoadmapDto.RoadmapResponse> generate(
            @AuthenticationPrincipal String username,
            @RequestBody CertRoadmapDto.GenerateRequest req) {
        return ApiResponse.ok(service.generate(username, req));
    }

    /** 내 로드맵 목록 */
    @GetMapping
    public ApiResponse<List<CertRoadmapDto.RoadmapSummary>> listMine(
            @AuthenticationPrincipal String username) {
        return ApiResponse.ok(service.listMine(username));
    }

    /** 로드맵 상세 */
    @GetMapping("/{id}")
    public ApiResponse<CertRoadmapDto.RoadmapResponse> getDetail(
            @AuthenticationPrincipal String username,
            @PathVariable Long id) {
        return ApiResponse.ok(service.getDetail(username, id));
    }

    /** 단계 완료 토글 */
    @PatchMapping("/{id}/steps/{stepId}/toggle")
    public ApiResponse<CertRoadmapDto.RoadmapResponse> toggleStep(
            @AuthenticationPrincipal String username,
            @PathVariable Long id,
            @PathVariable Long stepId) {
        return ApiResponse.ok(service.toggleStep(username, id, stepId));
    }

    /** 로드맵 삭제 */
    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(
            @AuthenticationPrincipal String username,
            @PathVariable Long id) {
        service.delete(username, id);
        return ApiResponse.ok("삭제 완료");
    }
}
