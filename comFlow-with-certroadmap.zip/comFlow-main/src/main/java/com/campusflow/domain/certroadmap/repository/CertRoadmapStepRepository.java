package com.campusflow.domain.certroadmap.repository;

import com.campusflow.domain.certroadmap.entity.CertRoadmapStep;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertRoadmapStepRepository extends JpaRepository<CertRoadmapStep, Long> {
}
