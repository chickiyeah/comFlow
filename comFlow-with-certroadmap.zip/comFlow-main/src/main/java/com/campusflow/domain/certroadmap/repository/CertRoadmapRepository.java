package com.campusflow.domain.certroadmap.repository;

import com.campusflow.domain.certroadmap.entity.CertRoadmap;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CertRoadmapRepository extends JpaRepository<CertRoadmap, Long> {
    List<CertRoadmap> findByStudentIdOrderByCreatedAtDesc(Long studentId);
}
