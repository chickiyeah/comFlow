package com.campusflow.domain.certroadmap.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "cert_roadmap_steps")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class CertRoadmapStep {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "roadmap_id", nullable = false)
    private CertRoadmap roadmap;

    /** 단계 순서 (1-based) */
    @Column(nullable = false)
    private int stepOrder;

    /** 단계 제목 (예: 1과목 - 소프트웨어 설계) */
    @Column(nullable = false, length = 200)
    private String title;

    /** 단계 상세 학습 내용 */
    @Column(columnDefinition = "TEXT")
    private String description;

    /** 권장 학습 기간 (예: 2주) */
    @Column(length = 50)
    private String duration;

    /** 완료 여부 (사용자가 체크) */
    @Column(nullable = false)
    private boolean completed;

    @Builder
    public CertRoadmapStep(int stepOrder, String title, String description, String duration) {
        this.stepOrder   = stepOrder;
        this.title       = title;
        this.description = description;
        this.duration    = duration;
        this.completed   = false;
    }

    void setRoadmap(CertRoadmap roadmap) {
        this.roadmap = roadmap;
    }

    public void toggle() {
        this.completed = !this.completed;
    }
}
