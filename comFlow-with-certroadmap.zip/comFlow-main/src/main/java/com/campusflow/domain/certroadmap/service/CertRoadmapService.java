package com.campusflow.domain.certroadmap.service;

import com.campusflow.domain.ai.service.AiFacadeService;
import com.campusflow.domain.certroadmap.dto.CertRoadmapDto;
import com.campusflow.domain.certroadmap.entity.CertRoadmap;
import com.campusflow.domain.certroadmap.entity.CertRoadmapStep;
import com.campusflow.domain.certroadmap.repository.CertRoadmapRepository;
import com.campusflow.domain.certroadmap.repository.CertRoadmapStepRepository;
import com.campusflow.domain.student.entity.Student;
import com.campusflow.domain.student.repository.StudentRepository;
import com.campusflow.domain.user.repository.UserRepository;
import com.campusflow.global.exception.BusinessException;
import com.campusflow.global.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CertRoadmapService {

    private final AiFacadeService           aiFacadeService;
    private final UserRepository            userRepository;
    private final StudentRepository         studentRepository;
    private final CertRoadmapRepository     roadmapRepository;
    private final CertRoadmapStepRepository stepRepository;
    private final ObjectMapper              objectMapper = new ObjectMapper();

    // ──────────────────────────────────────────────────────────────
    // 1. 로드맵 생성 (AI 호출)
    // ──────────────────────────────────────────────────────────────
    @Transactional
    public CertRoadmapDto.RoadmapResponse generate(String username, CertRoadmapDto.GenerateRequest req) {
        Student student = getStudent(username);

        if (req.getCertName() == null || req.getCertName().isBlank()) {
            throw new BusinessException(ErrorCode.INVALID_INPUT);
        }

        // AI에게 단계별 로드맵 요청 (JSON)
        AiResult ai = generateRoadmapByAi(req.getCertName());

        CertRoadmap roadmap = CertRoadmap.builder()
                .student(student)
                .certName(req.getCertName())
                .summary(ai.summary)
                .targetDate(req.getTargetDate())
                .build();

        int order = 1;
        for (AiStep s : ai.steps) {
            roadmap.addStep(CertRoadmapStep.builder()
                    .stepOrder(order++)
                    .title(s.title)
                    .description(s.description)
                    .duration(s.duration)
                    .build());
        }

        roadmapRepository.save(roadmap);
        return CertRoadmapDto.RoadmapResponse.from(roadmap);
    }

    // ──────────────────────────────────────────────────────────────
    // 2. 내 로드맵 목록
    // ──────────────────────────────────────────────────────────────
    public List<CertRoadmapDto.RoadmapSummary> listMine(String username) {
        Student student = getStudent(username);
        return roadmapRepository.findByStudentIdOrderByCreatedAtDesc(student.getId())
                .stream().map(CertRoadmapDto.RoadmapSummary::from).toList();
    }

    // ──────────────────────────────────────────────────────────────
    // 3. 로드맵 상세
    // ──────────────────────────────────────────────────────────────
    public CertRoadmapDto.RoadmapResponse getDetail(String username, Long roadmapId) {
        Student student = getStudent(username);
        return CertRoadmapDto.RoadmapResponse.from(loadOwned(student, roadmapId));
    }

    // ──────────────────────────────────────────────────────────────
    // 4. 단계 완료 토글
    // ──────────────────────────────────────────────────────────────
    @Transactional
    public CertRoadmapDto.RoadmapResponse toggleStep(String username, Long roadmapId, Long stepId) {
        Student student = getStudent(username);
        CertRoadmap roadmap = loadOwned(student, roadmapId);

        CertRoadmapStep step = roadmap.getSteps().stream()
                .filter(s -> s.getId().equals(stepId))
                .findFirst()
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND));
        step.toggle();

        return CertRoadmapDto.RoadmapResponse.from(roadmap);
    }

    // ──────────────────────────────────────────────────────────────
    // 5. 로드맵 삭제
    // ──────────────────────────────────────────────────────────────
    @Transactional
    public void delete(String username, Long roadmapId) {
        Student student = getStudent(username);
        CertRoadmap roadmap = loadOwned(student, roadmapId);
        roadmapRepository.delete(roadmap);
    }

    // ──────────────────────────────────────────────────────────────
    // AI 호출 + JSON 파싱
    // ──────────────────────────────────────────────────────────────
    private AiResult generateRoadmapByAi(String certName) {
        String system = """
                당신은 IT 자격증 취득을 돕는 학습 코치입니다.
                반드시 순수한 한국어로만 답변하세요. 한자, 영어 등 다른 언어는 절대 혼용하지 마세요.
                지정된 자격증의 학습 로드맵을 단계별로 설계합니다.
                반드시 아래 JSON 형식으로만 응답하세요. 마크다운, 설명, 코드블록 표시 없이 순수 JSON만 출력합니다.
                {
                  "summary": "자격증 한 줄 소개",
                  "steps": [
                    { "title": "단계 제목", "description": "학습 내용 상세", "duration": "권장 기간" }
                  ]
                }
                steps는 4~7개로 구성하세요.
                """;

        String user = String.format("""
                자격증: %s
                이 자격증을 처음 준비하는 2년제 컴퓨터정보과 학생을 위한 단계별 학습 로드맵을 만들어 주세요.
                필기/실기 구분이 있으면 반영하고, 각 단계마다 권장 학습 기간을 포함하세요.
                """, certName);

        try {
            String raw = aiFacadeService.ask(system, user);
            String json = extractJson(raw);
            JsonNode root = objectMapper.readTree(json);

            AiResult result = new AiResult();
            result.summary = root.path("summary").asText("");

            JsonNode stepsNode = root.path("steps");
            if (stepsNode.isArray()) {
                for (JsonNode n : stepsNode) {
                    AiStep step = new AiStep();
                    step.title       = n.path("title").asText("");
                    step.description = n.path("description").asText("");
                    step.duration    = n.path("duration").asText("");
                    if (!step.title.isBlank()) result.steps.add(step);
                }
            }

            if (result.steps.isEmpty()) {
                return fallback(certName);
            }
            return result;

        } catch (Exception e) {
            log.error("[CertRoadmap] AI 로드맵 생성/파싱 실패: {}", e.getMessage());
            return fallback(certName);
        }
    }

    /** AI 응답에서 JSON 부분만 추출 (코드블록이나 군더더기 제거) */
    private String extractJson(String raw) {
        if (raw == null) return "{}";
        int start = raw.indexOf('{');
        int end   = raw.lastIndexOf('}');
        if (start >= 0 && end > start) {
            return raw.substring(start, end + 1);
        }
        return raw;
    }

    /** AI 실패 시 기본 로드맵 */
    private AiResult fallback(String certName) {
        AiResult r = new AiResult();
        r.summary = certName + " 취득을 위한 기본 학습 로드맵입니다.";
        r.steps.add(makeStep("1단계 - 시험 정보 파악", "출제 범위, 합격 기준, 시험 일정을 확인하고 학습 계획을 세웁니다.", "1주"));
        r.steps.add(makeStep("2단계 - 핵심 이론 학습", "주요 개념과 이론을 교재나 인터넷 강의로 학습합니다.", "4주"));
        r.steps.add(makeStep("3단계 - 기출문제 풀이", "최근 기출문제를 반복해서 풀며 출제 경향을 익힙니다.", "3주"));
        r.steps.add(makeStep("4단계 - 약점 보완", "오답을 정리하고 부족한 단원을 집중 복습합니다.", "2주"));
        r.steps.add(makeStep("5단계 - 최종 마무리", "모의고사로 실전 감각을 키우고 시험에 응시합니다.", "1주"));
        return r;
    }

    private AiStep makeStep(String title, String desc, String dur) {
        AiStep s = new AiStep();
        s.title = title; s.description = desc; s.duration = dur;
        return s;
    }

    // 내부 파싱용 클래스
    private static class AiResult {
        String summary = "";
        java.util.List<AiStep> steps = new java.util.ArrayList<>();
    }
    private static class AiStep {
        String title = "", description = "", duration = "";
    }

    // ──────────────────────────────────────────────────────────────
    private Student getStudent(String username) {
        Long userId = userRepository.findByUsername(username)
                .orElseThrow(() -> new BusinessException(ErrorCode.UNAUTHORIZED))
                .getId();
        return studentRepository.findByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDENT_NOT_FOUND));
    }

    private CertRoadmap loadOwned(Student student, Long roadmapId) {
        CertRoadmap roadmap = roadmapRepository.findById(roadmapId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND));
        if (!roadmap.getStudent().getId().equals(student.getId())) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }
        return roadmap;
    }
}
