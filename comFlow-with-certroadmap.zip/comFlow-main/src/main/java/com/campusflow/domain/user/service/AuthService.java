package com.campusflow.domain.user.service;

import com.campusflow.domain.student.entity.Student;
import com.campusflow.domain.student.repository.StudentRepository;
import com.campusflow.domain.user.dto.LoginRequest;
import com.campusflow.domain.user.dto.RegisterRequest;
import com.campusflow.domain.user.dto.TokenResponse;
import com.campusflow.domain.user.entity.Role;
import com.campusflow.domain.user.entity.User;
import com.campusflow.domain.user.repository.UserRepository;
import com.campusflow.global.exception.BusinessException;
import com.campusflow.global.exception.ErrorCode;
import com.campusflow.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final EmailVerificationService emailVerificationService;

    @Transactional
    public void register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.username())) {
            throw new BusinessException(ErrorCode.DUPLICATE_STUDENT_ID);
        }
        if (userRepository.existsByEmail(request.email())) {
            throw new BusinessException(ErrorCode.DUPLICATE_EMAIL);
        }
        if (!emailVerificationService.isVerified(request.email())) {
            throw new BusinessException(ErrorCode.EMAIL_NOT_VERIFIED);
        }

        User user = User.builder()
                .username(request.username())
                .password(passwordEncoder.encode(request.password()))
                .name(request.name())
                .email(request.email())
                .role(request.role())
                .build();
        userRepository.save(user);

        // 학생 역할이면 Student 엔티티도 생성 (grade/semester는 1학년 1학기 기본값)
        if (request.role() == Role.ROLE_STUDENT) {
            Student student = Student.builder()
                    .user(user)
                    .studentId(request.username())
                    .name(request.name())
                    .grade(1)
                    .semester(1)
                    .department("컴퓨터정보과")
                    .email(request.email())
                    .build();
            studentRepository.save(student);
        }
    }

    public TokenResponse login(LoginRequest request) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.username(), request.password())
            );
            String token = tokenProvider.generateToken(auth);
            User user = userRepository.findByUsername(request.username())
                    .orElseThrow(() -> new BusinessException(ErrorCode.STUDENT_NOT_FOUND));
            return new TokenResponse(token, user.getName(), user.getRole().name());
        } catch (BadCredentialsException e) {
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS);
        }
    }

    /** 로그인 없이 테스트용 — testuser 계정으로 자동 로그인 */
    public TokenResponse autoLogin() {
        User user = userRepository.findByUsername("testuser")
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDENT_NOT_FOUND));
        Authentication auth = new UsernamePasswordAuthenticationToken(
                user.getUsername(), null,
                java.util.List.of(new org.springframework.security.core.authority.SimpleGrantedAuthority(user.getRole().name()))
        );
        String token = tokenProvider.generateToken(auth);
        return new TokenResponse(token, user.getName(), user.getRole().name());
    }
}
