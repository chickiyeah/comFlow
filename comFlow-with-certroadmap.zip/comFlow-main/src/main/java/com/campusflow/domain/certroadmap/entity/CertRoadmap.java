package com.campusflow.domain.certroadmap.entity;

import com.campusflow.domain.student.entity.Student;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cert_roadmaps")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EntityListeners(AuditingEntityListener.class)
public class CertRoadmap {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** 목표 자격증명 (예: 정보처리기사) */
    @Column(nullable = false, length = 100)
    private String certName;

    /** 자격증 개요 / AI가 생성한 한 줄 설명 */
    @Column(columnDefinition = "TEXT")
    private String summary;

    /** 시험 목표일 (D-day 계산용) */
    private LocalDate targetDate;

    @OneToMany(mappedBy = "roadmap", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("stepOrder ASC")
    private List<CertRoadmapStep> steps = new ArrayList<>();

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @Builder
    public CertRoadmap(Student student, String certName, String summary, LocalDate targetDate) {
        this.student    = student;
        this.certName   = certName;
        this.summary    = summary;
        this.targetDate = targetDate;
    }

    public void addStep(CertRoadmapStep step) {
        this.steps.add(step);
        step.setRoadmap(this);
    }
}
