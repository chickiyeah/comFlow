package com.campusflow.domain.certroadmap.dto;

import com.campusflow.domain.certroadmap.entity.CertRoadmap;
import com.campusflow.domain.certroadmap.entity.CertRoadmapStep;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class CertRoadmapDto {

    /** 생성 요청 */
    @Getter
    public static class GenerateRequest {
        private String certName;
        private LocalDate targetDate;   // 선택 (null 가능)
    }

    /** 로드맵 응답 */
    @Getter
    @Builder
    public static class RoadmapResponse {
        private Long id;
        private String certName;
        private String summary;
        private LocalDate targetDate;
        private Long dDay;              // 목표일까지 남은 일수 (null 가능)
        private int totalSteps;
        private int completedSteps;
        private int progressPercent;
        private List<StepItem> steps;
        private LocalDateTime createdAt;

        public static RoadmapResponse from(CertRoadmap r) {
            List<StepItem> items = r.getSteps().stream().map(StepItem::from).toList();
            int total = items.size();
            int done  = (int) items.stream().filter(StepItem::isCompleted).count();
            int pct   = total == 0 ? 0 : (int) Math.round(done * 100.0 / total);

            Long dday = null;
            if (r.getTargetDate() != null) {
                dday = ChronoUnit.DAYS.between(LocalDate.now(), r.getTargetDate());
            }

            return RoadmapResponse.builder()
                    .id(r.getId())
                    .certName(r.getCertName())
                    .summary(r.getSummary())
                    .targetDate(r.getTargetDate())
                    .dDay(dday)
                    .totalSteps(total)
                    .completedSteps(done)
                    .progressPercent(pct)
                    .steps(items)
                    .createdAt(r.getCreatedAt())
                    .build();
        }
    }

    @Getter
    @Builder
    public static class StepItem {
        private Long id;
        private int stepOrder;
        private String title;
        private String description;
        private String duration;
        private boolean completed;

        public static StepItem from(CertRoadmapStep s) {
            return StepItem.builder()
                    .id(s.getId())
                    .stepOrder(s.getStepOrder())
                    .title(s.getTitle())
                    .description(s.getDescription())
                    .duration(s.getDuration())
                    .completed(s.isCompleted())
                    .build();
        }
    }

    /** 목록용 요약 */
    @Getter
    @Builder
    public static class RoadmapSummary {
        private Long id;
        private String certName;
        private LocalDate targetDate;
        private Long dDay;
        private int progressPercent;
        private LocalDateTime createdAt;

        public static RoadmapSummary from(CertRoadmap r) {
            int total = r.getSteps().size();
            int done  = (int) r.getSteps().stream().filter(CertRoadmapStep::isCompleted).count();
            int pct   = total == 0 ? 0 : (int) Math.round(done * 100.0 / total);
            Long dday = r.getTargetDate() == null ? null
                    : ChronoUnit.DAYS.between(LocalDate.now(), r.getTargetDate());
            return RoadmapSummary.builder()
                    .id(r.getId())
                    .certName(r.getCertName())
                    .targetDate(r.getTargetDate())
                    .dDay(dday)
                    .progressPercent(pct)
                    .createdAt(r.getCreatedAt())
                    .build();
        }
    }
}
