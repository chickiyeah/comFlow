package com.campusflow.config;

import com.campusflow.domain.portfolio.entity.Portfolio;
import com.campusflow.domain.portfolio.entity.PortfolioStatus;
import com.campusflow.domain.portfolio.repository.PortfolioRepository;
import com.campusflow.domain.student.entity.Student;
import com.campusflow.domain.student.repository.StudentRepository;
import com.campusflow.domain.user.entity.Role;
import com.campusflow.domain.user.entity.User;
import com.campusflow.domain.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * 로그인 없이 테스트하기 위한 자동 계정 생성기.
 * 서버 시작 시 testuser 계정이 없으면 생성한다.
 * 프론트엔드가 이 계정으로 자동 로그인한다.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TestUserInitializer implements ApplicationRunner {

    public static final String TEST_USERNAME = "testuser";
    public static final String TEST_PASSWORD = "test1234";

    private final UserRepository      userRepository;
    private final StudentRepository   studentRepository;
    private final PortfolioRepository portfolioRepository;
    private final PasswordEncoder     passwordEncoder;

    @Override
    public void run(ApplicationArguments args) {
        if (userRepository.existsByUsername(TEST_USERNAME)) {
            log.info("[TestUserInitializer] 테스트 계정 이미 존재 — 생성 생략");
            return;
        }

        User user = userRepository.save(User.builder()
                .username(TEST_USERNAME)
                .password(passwordEncoder.encode(TEST_PASSWORD))
                .name("테스트 학생")
                .email("testuser@campusflow.local")
                .role(Role.ROLE_STUDENT)
                .build());

        Student student = studentRepository.save(Student.builder()
                .user(user)
                .studentId(TEST_USERNAME)
                .name("테스트 학생")
                .grade(2)
                .semester(1)
                .department("컴퓨터정보과")
                .email("testuser@campusflow.local")
                .build());

        // 가상면접용 샘플 포트폴리오
        try {
            portfolioRepository.save(Portfolio.builder()
                    .student(student)
                    .title("CampusFlow 학과 통합 관리 시스템")
                    .role("백엔드 개발")
                    .techStack("Java, Spring Boot, JPA, MySQL, React")
                    .description("학과 성적·출결·포트폴리오·취업을 AI와 연계해 통합 관리하는 플랫폼. JWT 인증, AI 폴백 체인 구현.")
                    .startDate(LocalDate.now().minusMonths(3))
                    .endDate(LocalDate.now())
                    .status(PortfolioStatus.COMPLETED)
                    .build());
        } catch (Exception e) {
            log.warn("[TestUserInitializer] 샘플 포트폴리오 생성 실패 (무시): {}", e.getMessage());
        }

        log.info("[TestUserInitializer] 테스트 계정 생성 완료 (username={})", TEST_USERNAME);
    }
}
