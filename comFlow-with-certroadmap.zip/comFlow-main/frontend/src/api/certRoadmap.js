import api from './axios'

export const generateCertRoadmap = (certName, targetDate) =>
  api.post('/cert-roadmap/generate', { certName, targetDate })

export const listCertRoadmaps = () =>
  api.get('/cert-roadmap')

export const getCertRoadmap = (id) =>
  api.get(`/cert-roadmap/${id}`)

export const toggleCertStep = (id, stepId) =>
  api.patch(`/cert-roadmap/${id}/steps/${stepId}/toggle`)

export const deleteCertRoadmap = (id) =>
  api.delete(`/cert-roadmap/${id}`)
