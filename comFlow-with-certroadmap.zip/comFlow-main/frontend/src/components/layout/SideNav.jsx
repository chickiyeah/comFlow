import { useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import useAuthStore from '../../store/authStore'

const NAV_ITEMS = [
  { path: '/dashboard',  icon: 'dashboard',      key: 'dashboard'  },
  { path: '/academic',   icon: 'school',         key: 'academic'   },
  { path: '/facilities', icon: 'corporate_fare', key: 'facilities' },
  { path: '/career',     icon: 'work',           key: 'career'     },
  { path: '/interview',  icon: 'record_voice_over', key: 'interview' },
  { path: '/cert-roadmap', icon: 'school',        key: 'certRoadmap' },
  { path: '/technical',  icon: 'description',    key: 'technical'  },
  { path: '/calendar',   icon: 'calendar_month', key: 'calendar'   },
  { path: '/study',      icon: 'groups',         key: 'study'      },
  { path: '/profile',    icon: 'manage_accounts',key: 'profile'    },
]

export default function SideNav() {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const user = useAuthStore(s => s.user)
  const isAdmin = user?.role === 'ROLE_ADMIN'
  const items = isAdmin
    ? [...NAV_ITEMS, { path: '/admin', icon: 'admin_panel_settings', key: 'admin' }]
    : NAV_ITEMS

  return (
    <aside className="fixed left-0 top-0 h-full w-20 flex flex-col items-center py-4 z-50
      bg-primary-container dark:bg-[#0f1629]
      border-r border-primary/20 dark:border-[#1e2a45]
      shadow-nav">

      {/* Logo */}
      <button onClick={() => navigate('/')} className="flex flex-col items-center mb-8 hover:opacity-80 transition-opacity active:scale-95">
        <span className="text-secondary-fixed font-black text-2xl font-['Space_Grotesk']">CF</span>
        <span className="text-primary-fixed-dim/50 text-[8px] font-bold tracking-wider font-['Space_Grotesk']">v1.0</span>
      </button>

      {/* Nav */}
      <nav className="flex flex-col items-center flex-1 space-y-6 w-full">
        {items.map(({ path, icon, key }) => {
          const active = pathname === path || (path !== '/' && pathname.startsWith(path))
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={
                active
                  ? 'flex flex-col items-center justify-center w-14 h-14 bg-secondary-fixed text-on-secondary-fixed rounded-xl shadow-lime transition-transform active:scale-95'
                  : 'group flex flex-col items-center justify-center text-primary-fixed-dim/70 hover:text-white transition-all duration-200 w-full py-2'
              }
            >
              <span className="material-symbols-outlined text-[22px] group-hover:scale-110 transition-transform">
                {icon}
              </span>
              <span className="font-['Space_Grotesk'] text-[8px] uppercase tracking-wider font-medium mt-1">
                {t(`nav.${key}`, key === 'admin' ? '관리자' : key)}
              </span>
            </button>
          )
        })}
      </nav>

      {/* Support */}
      <div className="mt-auto">
        <button className="group flex flex-col items-center text-primary-fixed-dim/70 hover:text-white transition-all duration-200 py-2 w-full">
          <span className="material-symbols-outlined text-[22px] group-hover:scale-110 transition-transform">help_outline</span>
          <span className="font-['Space_Grotesk'] text-[8px] uppercase tracking-wider font-medium mt-1">Support</span>
        </button>
      </div>
    </aside>
  )
}
