import { useState, useEffect } from 'react'
import Layout from '../components/layout/Layout'
import {
  generateCertRoadmap, listCertRoadmaps, getCertRoadmap,
  toggleCertStep, deleteCertRoadmap
} from '../api/certRoadmap'

// 추천 자격증 (빠른 선택용)
const POPULAR_CERTS = [
  '정보처리기사', '정보처리산업기사', 'SQLD', '리눅스마스터 2급',
  '네트워크관리사 2급', '컴퓨터활용능력 1급', '정보보안기사',
]

export default function CertRoadmap() {
  const [view, setView]         = useState('list')   // list | detail
  const [roadmaps, setRoadmaps] = useState([])
  const [current, setCurrent]   = useState(null)
  const [loading, setLoading]   = useState(true)

  // 생성 폼
  const [certName, setCertName]     = useState('')
  const [targetDate, setTargetDate] = useState('')
  const [generating, setGenerating] = useState(false)

  const loadList = () => {
    setLoading(true)
    listCertRoadmaps()
      .then(res => setRoadmaps(res.data || []))
      .finally(() => setLoading(false))
  }

  useEffect(() => { loadList() }, [])

  const handleGenerate = async () => {
    if (!certName.trim()) return alert('자격증 이름을 입력하거나 선택해 주세요.')
    setGenerating(true)
    try {
      const res = await generateCertRoadmap(certName.trim(), targetDate || null)
      setCurrent(res.data)
      setView('detail')
      setCertName('')
      setTargetDate('')
      loadList()
    } catch {
      alert('로드맵 생성에 실패했습니다. 잠시 후 다시 시도해 주세요.')
    } finally {
      setGenerating(false)
    }
  }

  const openDetail = async (id) => {
    const res = await getCertRoadmap(id)
    setCurrent(res.data)
    setView('detail')
  }

  const handleToggle = async (stepId) => {
    const res = await toggleCertStep(current.id, stepId)
    setCurrent(res.data)
  }

  const handleDelete = async (id) => {
    if (!confirm('이 로드맵을 삭제하시겠습니까?')) return
    await deleteCertRoadmap(id)
    if (current?.id === id) { setView('list'); setCurrent(null) }
    loadList()
  }

  return (
    <Layout title="자격증 로드맵">
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-medium text-primary dark:text-white">자격증 로드맵</h1>
          <span className="chip">AI 학습 플래너</span>
        </div>

        {view === 'list' && (
          <ListView
            roadmaps={roadmaps}
            loading={loading}
            certName={certName}
            setCertName={setCertName}
            targetDate={targetDate}
            setTargetDate={setTargetDate}
            generating={generating}
            onGenerate={handleGenerate}
            onOpen={openDetail}
            onDelete={handleDelete}
          />
        )}

        {view === 'detail' && current && (
          <DetailView
            roadmap={current}
            onToggle={handleToggle}
            onBack={() => { setView('list'); loadList() }}
            onDelete={() => handleDelete(current.id)}
          />
        )}
      </div>
    </Layout>
  )
}

// ──────────────────────────────────────────────────────────────
// 목록 + 생성 폼
// ──────────────────────────────────────────────────────────────
function ListView({ roadmaps, loading, certName, setCertName, targetDate, setTargetDate, generating, onGenerate, onOpen, onDelete }) {
  return (
    <div className="space-y-6">
      {/* 생성 폼 */}
      <div className="card p-5 space-y-4">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          취득하고 싶은 자격증을 선택하면 AI가 단계별 학습 로드맵과 일정을 만들어 줍니다.
        </p>

        {/* 추천 자격증 칩 */}
        <div className="flex flex-wrap gap-2">
          {POPULAR_CERTS.map(c => (
            <button
              key={c}
              onClick={() => setCertName(c)}
              className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${
                certName === c
                  ? 'bg-primary text-white border-primary'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-primary/50'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-slate-500 mb-1 block">자격증 이름</label>
            <input
              className="input w-full"
              placeholder="예: 정보처리기사"
              value={certName}
              onChange={e => setCertName(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs text-slate-500 mb-1 block">시험 목표일 (선택)</label>
            <input
              type="date"
              className="input w-full"
              value={targetDate}
              onChange={e => setTargetDate(e.target.value)}
            />
          </div>
        </div>

        <button onClick={onGenerate} disabled={generating} className="btn-primary w-full">
          {generating ? 'AI가 로드맵 생성 중…' : '로드맵 생성'}
        </button>
      </div>

      {/* 저장된 로드맵 목록 */}
      <div className="space-y-3">
        <h2 className="text-sm font-medium text-slate-600 dark:text-slate-300">내 로드맵</h2>
        {loading ? (
          <p className="text-sm text-slate-400 py-4 text-center">불러오는 중…</p>
        ) : roadmaps.length === 0 ? (
          <p className="text-sm text-slate-400 py-8 text-center">아직 생성한 로드맵이 없습니다.</p>
        ) : (
          roadmaps.map(r => (
            <div key={r.id} className="card p-4 hover:border-primary/40 transition-colors">
              <div className="flex items-start justify-between">
                <button onClick={() => onOpen(r.id)} className="text-left flex-1">
                  <p className="font-medium text-slate-700 dark:text-slate-200">{r.certName}</p>
                  <div className="flex items-center gap-3 mt-1.5">
                    <DdayBadge dday={r.dDay} />
                    <span className="text-xs text-slate-400">진행률 {r.progressPercent}%</span>
                  </div>
                  {/* 진행 바 */}
                  <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mt-2 max-w-xs">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${r.progressPercent}%` }} />
                  </div>
                </button>
                <button onClick={() => onDelete(r.id)} className="text-xs text-red-400 hover:text-red-600 ml-4 shrink-0">삭제</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────────────
// 상세 — 단계별 체크리스트
// ──────────────────────────────────────────────────────────────
function DetailView({ roadmap, onToggle, onBack, onDelete }) {
  return (
    <div className="space-y-5">
      <button onClick={onBack} className="text-sm text-slate-500 hover:text-primary">← 목록으로</button>

      {/* 헤더 카드 */}
      <div className="card p-5 space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-medium text-primary dark:text-white">{roadmap.certName}</h2>
            {roadmap.summary && (
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{roadmap.summary}</p>
            )}
          </div>
          <DdayBadge dday={roadmap.dDay} large />
        </div>

        {/* 진행 현황 */}
        <div>
          <div className="flex items-center justify-between text-sm mb-1">
            <span className="text-slate-500">진행률</span>
            <span className="font-medium text-primary">
              {roadmap.completedSteps} / {roadmap.totalSteps} 단계 ({roadmap.progressPercent}%)
            </span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${roadmap.progressPercent}%` }} />
          </div>
        </div>
      </div>

      {/* 단계 목록 */}
      <div className="space-y-3">
        {roadmap.steps.map(step => (
          <div
            key={step.id}
            className={`card p-4 flex gap-3 transition-colors ${
              step.completed ? 'bg-primary/5 dark:bg-primary/10 border-primary/30' : ''
            }`}
          >
            {/* 체크박스 */}
            <button
              onClick={() => onToggle(step.id)}
              className={`shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center mt-0.5 transition-colors ${
                step.completed
                  ? 'bg-primary border-primary text-white'
                  : 'border-slate-300 dark:border-slate-600 hover:border-primary'
              }`}
            >
              {step.completed && <span className="text-xs">✓</span>}
            </button>

            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`font-medium ${step.completed ? 'text-slate-400 line-through' : 'text-slate-700 dark:text-slate-200'}`}>
                  {step.title}
                </span>
                {step.duration && (
                  <span className="chip text-xs">{step.duration}</span>
                )}
              </div>
              {step.description && (
                <p className={`text-sm mt-1 leading-relaxed ${step.completed ? 'text-slate-400' : 'text-slate-500 dark:text-slate-400'}`}>
                  {step.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      <button onClick={onDelete} className="btn-secondary w-full text-red-500">이 로드맵 삭제</button>
    </div>
  )
}

// ──────────────────────────────────────────────────────────────
// D-day 뱃지
// ──────────────────────────────────────────────────────────────
function DdayBadge({ dday, large }) {
  if (dday === null || dday === undefined) {
    return <span className={`text-slate-400 ${large ? 'text-sm' : 'text-xs'}`}>목표일 미설정</span>
  }
  const isPast = dday < 0
  const label = isPast ? `D+${Math.abs(dday)}` : dday === 0 ? 'D-Day' : `D-${dday}`
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full font-medium ${
      large ? 'text-sm' : 'text-xs'
    } ${
      isPast
        ? 'bg-slate-100 text-slate-500 dark:bg-slate-800'
        : dday <= 7
          ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
          : 'bg-primary/10 text-primary'
    }`}>
      {label}
    </span>
  )
}
